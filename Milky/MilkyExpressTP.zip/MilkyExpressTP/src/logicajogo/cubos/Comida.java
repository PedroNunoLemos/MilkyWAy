package logicajogo.cubos;

import java.awt.Color;

public class Comida extends Cubo{
	
	public Comida() {
		super(Color.yellow);
		this.defineNome("Comida");
	}
	
}
