
package logicajogo.cubos;

import java.awt.Color;

public class Ilegal extends Cubo {

	public Ilegal() {

		super(Color.black);
		this.defineNome("Ilegal");

	}

}
