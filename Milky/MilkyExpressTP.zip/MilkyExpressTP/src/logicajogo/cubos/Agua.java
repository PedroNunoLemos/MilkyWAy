package logicajogo.cubos;

import java.awt.Color;

public class Agua extends Cubo{
	
	public Agua() {
		super(Color.blue);
		this.defineNome("Agua");
		
	}
    
}
