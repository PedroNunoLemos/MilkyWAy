package logicajogo.cubos;

import java.awt.Color;

public class Cinzento extends Cubo {
	
	public Cinzento() {
		super(Color.gray);
		
		this.defineNome("Cinzento");
		
	}

}
