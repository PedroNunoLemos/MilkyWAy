
package logicajogo.cubos;

import java.awt.Color;

public class Medicamento extends Cubo{
	
	public Medicamento() {

		super(Color.red);
		this.defineNome("Medicamento");
	}
    
}
