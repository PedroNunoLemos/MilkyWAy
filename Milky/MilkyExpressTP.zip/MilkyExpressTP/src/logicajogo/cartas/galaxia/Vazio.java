package logicajogo.cartas.galaxia;

import logicajogo.cartas.Carta;

public class Vazio extends Carta {
	
	public Vazio(){
		
		nome="Vazio";
	}

}
