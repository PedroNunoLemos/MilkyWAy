package logicajogo.cartas.galaxia;

import logicajogo.cartas.Carta;

public class BuracoNegro extends Carta {
	
	public BuracoNegro(){
		
		nome="BuracoNegro";
	}

}
