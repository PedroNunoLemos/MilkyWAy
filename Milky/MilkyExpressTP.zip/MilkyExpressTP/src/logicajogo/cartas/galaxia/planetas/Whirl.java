
package logicajogo.cartas.galaxia.planetas;


import logicajogo.cubos.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Whirl extends PlanetaPirata{
    
    
        public Whirl(){
        	
        	
        nome = "Arrakis";
        precario.put(new Comida(),3);
        
        
    }
}
