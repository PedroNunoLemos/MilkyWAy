
package logicajogo.cartas.galaxia.planetas;

import logicajogo.cubos.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Asperta extends PlanetaPirata{    
    
        public Asperta(){
        	
        nome = "Asperta";
        precario.put(new Agua(), 3);
        
        
    }
}
