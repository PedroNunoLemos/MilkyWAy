
package logicajogo.cartas.galaxia.planetas;

import logicajogo.cubos.Medicamento;


public class Striterax extends PlanetaPirata{    
    
        public Striterax(){
        	
        nome = "Striterax";
        precario.put(new Medicamento(), 3);
        
    }
}
