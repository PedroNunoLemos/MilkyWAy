package logicajogo.dados;

public abstract class Dado {
	
	public abstract void lancarDado();
	
}
