package programa;

import logicajogo.Jogo;
import logicajogo.estados.IniciarJogo;
import ui.texto.Tui;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		Tui text = new Tui();
		text.mostraInterface();

		
	}

}
